<?php

namespace App\Models\Policy;

use Illuminate\Database\Eloquent\Model;

class PolicyCategory extends Model
{
    //
}