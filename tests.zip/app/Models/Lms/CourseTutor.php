<?php

namespace App\Models\Lms;

use Illuminate\Database\Eloquent\Model;

class CourseTutor extends Model
{
    //
}
