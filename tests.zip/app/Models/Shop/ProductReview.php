<?php

namespace App\Models\Shop;

use Illuminate\Database\Eloquent\Model;

class ProductReview extends Model
{
    //
}
