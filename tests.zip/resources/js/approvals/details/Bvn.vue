<template>
<section>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    A list of the User details here
                </div>
            </div>
        </div>
    </div>
</section>
</template>