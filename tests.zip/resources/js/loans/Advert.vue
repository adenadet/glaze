<template>
<section class="card custom-card overflow-hidden"> 
    <div class="card-body"> 
        <div class="row gap-3 gap-sm-0"> 
            <div class="col-sm-8 col-12"> 
                <div class=""> 
                    <h4 class="fw-semibold mb-2">Get a loan at <span class="text-primary">2%</span> monthly</h4> 
                    <p class="mb-4 text-muted fs-14 op-7"> Glaze Credit Offers amazing loans for both personal and business. With such great competitive rates it is hard to ignore.</p>
                    <div class="btn-list pt-1"> 
                        <button class="btn btn-primary btn-wave m-1 waves-effect waves-light">Start Now</button> 
                        <button class="btn btn-outline-primary btn-wave m-1 waves-effect waves-light">Create Yours</button> 
                    </div> 
                </div> 
            </div> 
            <div class="col-sm-4 col-auto my-auto"> 
                <div class="featured-nft"> <img src="/assets/images/nft-images/1.png" alt=""> </div> 
            </div> 
        </div> 
    </div> 
</section>
</template>