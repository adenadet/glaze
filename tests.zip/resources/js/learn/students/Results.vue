<template>
<div>
1. Load Per Exam
2. Load Per Course
</div>
</template>
<script>
</script>
