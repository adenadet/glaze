<?php

namespace App\Models\Lms;

use Illuminate\Database\Eloquent\Model;

class LessonType extends Model
{
    //
}
