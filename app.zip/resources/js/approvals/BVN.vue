<template>
<section class="container-fluid">
    <div class="row">
        
        <div class="col-md-10 offset-md-1">
            <div class="card">
                <div class="card-body">
                    <ApproveFormBvn />
                </div>
            </div>
        </div>
    </div>
</section>
</template>