<template>
    <p>A list of all active loans in one tab and pending loans in another tab</p>
</template>