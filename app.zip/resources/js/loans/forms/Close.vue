<template>
<section>
    <p>Put the necessary things to close an account here. This should include payment details. Ask Mr. Ahmed for hard copy else.</p>
</section>
</template>