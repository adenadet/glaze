<template>
<section class="container-fluid">
    <div class="row justify-content-center">
        <h3>Thank You</h3>
        <p>You have successfully responded to the loan request.</p>
    </div>
</section>
</template>