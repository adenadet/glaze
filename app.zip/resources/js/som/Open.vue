<template>
<section class="row">
    <div class="col-12 col-md-12 col-sm-6">
        <div class="card card-primary card-tabs">
            Put a form here, select month that is no open for Nomination, check if any active month's nomination is available. If yes. a new month's nomination can not be opened. Same should apply to new Voting. 
            <!--<div class="card-header p-0 pt-1">
                <ul class="nav nav-tabs" id="custom-tabs-five-tab" role="tablist">
                    <li class="nav-item"><a class="nav-link active" id="custom-tabs-five-overlay-tab" data-toggle="pill" href="#custom-tabs-five-overlay" role="tab" aria-controls="custom-tabs-five-overlay" aria-selected="true">Nominations</a></li>
                    <li class="nav-item"><a class="nav-link" id="custom-tabs-five-overlay-dark-tab" data-toggle="pill" href="#custom-tabs-five-overlay-dark" role="tab" aria-controls="custom-tabs-five-overlay-dark" aria-selected="false">Voting</a></li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="custom-tabs-five-tabContent">
                    <div class="tab-pane fade show active" id="custom-tabs-five-overlay" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-tab"><SOMOpenNominations /></div>
                    <div class="tab-pane fade" id="custom-tabs-five-overlay-dark" role="tabpanel" aria-labelledby="custom-tabs-five-overlay-dark-tab"><SOMOpenVoting /></div>
                </div>
            </div>-->
        </div> 
    </div>  
</section>
</template>
